﻿namespace CoreIstanbulReservationApp.Models
{
    public class Instruments
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
