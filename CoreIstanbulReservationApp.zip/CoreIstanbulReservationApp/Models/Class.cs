﻿namespace CoreIstanbulReservationApp.Models
{
    public class Class
    {
    }
}
